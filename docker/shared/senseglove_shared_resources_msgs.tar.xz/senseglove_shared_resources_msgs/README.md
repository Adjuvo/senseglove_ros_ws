# senseglove_shared_resources_msgs
Custom msgs for ROS1_bridge
